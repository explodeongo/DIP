img = imread('test.png'); % replace 'test.png' with the actual image file

% Display the image with truesize option
figure;
imshow(img, 'truesize');
title('Original Image');

% Pause to keep the figure window open
pause;

