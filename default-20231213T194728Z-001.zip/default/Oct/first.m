%Effect of reducing the quantization value

clear all
clc
a = imread('C:\Users\hrc\Downloads\totem.tif');
a = double(a);
a = a+1
b = max(max(a));
i = input('how many bits do you want? 1 2 4 8 ');
j = b/(2^i);
F= floor(a/(j+1));
F1 = (F*255)/max(max(F));
figure(1)
imshow(uint8(a))
figure(2)
imshow(uint8(F1))
