%Digital Negative


clear all;
clc;
aa = imread('C:\Users\hrc\Downloads\2.jpg');
a = double (aa)
c = 255;
b = c-a;
figure(1)
colormap(gray)
imagesc(a)
figure(2)
colormap(gray)
imagesc(b)


