%Dilation and Erosion of real image
clear all
clc
a=imread('circbw.tif');
p=size(a);
s=strel('square',3);
d1=imdilate(a,s);
d2=imdilate(a,s);
w=[1 1 1;1 1 1; 1 1 1 ];
for x = 2:1:p(1)-1
  for y = 2:1:p(2)-1
    a1=[w(1)*a(x-1,y-1) w(2)*a(x-1,y) w(3)*a(x-1,y+1) w(4)*a(x,y-1) w(5)*a(x,y) w(6)*a(x,y+1) w(7)*a(x+1,y-1) w(8)*a(x+1,y) w(9)*a(x+1,y+1)];
  A1(x,y)=max(a1);
  A2(x,y)=min(a1);
endfor
endfor
subplot(2,3,1),imshow(a),title('a')
subplot(2,3,2),imshow(d1),title('dl')
subplot(2,3,3),imshow(d2),title('d2')
subplot(2,3,4),imshow(A1),title('A1')
subplot(2,3,5),imshow(A2),title('A2')


