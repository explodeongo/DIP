%Region filling

clear all
clc
a= imread("reg.jpg");
a=im2bw(a);
str=[0 1 0;1 1 1;0 1 0];
[row col]=size(a);
const=1;

b=zeros(row,col);
figure(1)
imshow(a)
[X,Y]=ginput(1);
X=round(X);
Y=round(Y);
b(Y,X)=1;
temp=b;
while const ==1;
  c=imdilate(b,str);
  r1=and(c,not(a));
  if r1 ==b
    const=0;
  else
    b=r1;

  end
end
a;
region_fill=or(a,r1);
figure(2)
imshow(region_fill)


