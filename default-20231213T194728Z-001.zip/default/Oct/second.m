% Effect of reducing the numbver of samples

clear all
clc

a = imread('C:/Users/hrc/Downloads/totem.tif');
[row,col]=size(a)
i = 1; j=1;

for x=1:2:row
  for y = 1:2:col
    c(i,j)=a(x,y);
    j = j+1;

  end
  j = 1;
  i=i+1;
end
figure(1),imshow(a)
figure(2),imshow(c)
figure(3),
imagesc(a),colormap(gray)
figure(4)
imagesc(c),colormap(white)

