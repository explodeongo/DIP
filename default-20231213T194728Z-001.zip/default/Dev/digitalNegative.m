%%MATLAB code to calculate negative %%
clear all;
clc;
aa=imread('eye.tif');
a = double(aa);
c=255; % for a 8 bit image %
b = c-a;
figure(1);
colormap(gray);
imagesc(a);
figure(2);
colormap(gray);
imagesc(b);
