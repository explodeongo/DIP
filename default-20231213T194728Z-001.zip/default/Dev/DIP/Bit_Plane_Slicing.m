clear all
clc
a = imread('Saturn.jpg');
a = double(a);
r = input("which bit image do you want to see 1 = MSB 8 = LSB");
[row,col] = size(a);

for x =1:1:row
  for y =1:1:col
  c = dec2bin(a(x,y),8);
  d = c(r);
  w(x,y) = double(d);

  if w(x,y) == 49
    w(x,y) = 255;
  else
    w(x,y) = 0;
  end
end
end

figure(1)
imshow(uint8(a))
figure(2)
imshow(uint8(w))
