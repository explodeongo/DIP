clear all
clc
a=imread('test.jpeg');
[row,col] = size(a);
i=1; j=1;
for x=1:2:row
for y=1:2:col
c(i,j)=a(x,y);
j=j+1;
end
j=1; %%This needs to be done else the value of j goes on increasing %%
i = i+1;
end
figure(1),imshow(a)
figure(2),imshow(c)
figure(3)
imagesc(a),colormap(gray)
figure(4)
imagesc(c),colormap(gray)
