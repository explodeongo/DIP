clear all
clc

% Load the image
a1 = imread('image.bmp');
a = double(a1);

% Get the size of the image
p = size(a);

% Structuring element for erosion and dilation
w = ones(3, 3);

% Initialize matrices for erosion and dilation results
A1 = zeros(p(1), p(2));
A2 = zeros(p(1), p(2));

% Erosion
for x = 2:p(1)-1
    for y = 2:p(2)-1
        % Extract the neighborhood using the structuring element
        neighborhood = a(x-1:x+1, y-1:y+1) .* w;
        A1(x, y) = min(neighborhood(:)); % Minimum value in the neighborhood
    end
end

% Dilation
for i = 2:p(1)-1
    for j = 2:p(2)-1
        % Extract the neighborhood using the structuring element
        neighborhood = a(i-1:i+1, j-1:j+1) .* w;
        A2(i, j) = max(neighborhood(:)); % Maximum value in the neighborhood
    end
end

% Display the results

figure(2), imshow(uint8(a));

figure(3), imshow(uint8(A2));


