clear all
clc
a = imread('image.bmp');
a=double(a);
p=size(a);
w=[1 1 1;1 1 1;1 1 1]; %%Structuring element%%
for x=2:1:p(1)-1
   for y=2:1:p(2)-1
     a1=[w(1)*a(x-1,y-1) w(2)*a(x-1,y) w(3)*a(x-1,y+1) w(4)*a(x,y-1) w(5)*a(x,y) w(6)*a(x,y+1) w(7)*a(x+1,y-1) w(8)*a(x+1,y) w(9)*a(x+1,y+1)];
     A1(x,y)=min(a1);      %%Erosion%%
   endfor
endfor
q=size(A1)
for i=2:1:q(1)-1
   for j=2:1:q(2)-1
     a2=[w(1)*a(i-1,j-1) w(2)*a(i-1,j) w(3)*a(i-1,j+1) w(4)*a(i,j-1) w(5)*a(i,j) w(6)*a(i,j+1) w(7)*a(i+1,j-1) w(8)*a(i+1,y) w(9)*a(i+1,j+1)];
     A2(i,j)=max(a2);      %%Dilation%%
   endfor
endfor


figure(1),imshow(a)
figure(2),imshow(A2)

