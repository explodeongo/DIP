clear all
clc

% Load the image
a1 = imread('image2.jpeg');
a = double(a1);

% Get the size of the image
p = size(a);

% Structuring element for erosion and dilation
w = ones(3, 3);

% Initialize matrices for erosion and dilation results
A1 = zeros(p(1), p(2));
A2 = zeros(p(1), p(2));

% Erosion
for x = 2:p(1)-1
    for y = 2:p(2)-1
        % Extract the neighborhood using the structuring element
        neighborhood = a(x-1:x+1, y-1:y+1) .* w;
        A1(x, y) = min(neighborhood(:)); % Minimum value in the neighborhood
    end
end

% Dilation
for i = 2:p(1)-1
    for j = 2:p(2)-1
        % Extract the neighborhood using the structuring element
        neighborhood = a(i-1:i+1, j-1:j+1) .* w;
        A2(i, j) = max(neighborhood(:)); % Maximum value in the neighborhood
    end
end

% Display the results
figure(1), imshow(a1);
title('Original');
figure(2), imshow(uint8(A1));
title('Erosion (A1)');

figure(3), imshow(uint8(A2));
title('Dilation (A2)');

