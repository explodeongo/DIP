clear all;
clc;
a=imread('mountain.tif');
a=double(a);
[row col]=size(a)
m=input('Enter the musk size:');
n=m^2;
for i=1:1:m
  for j=1:1:m
    w(i,j)=1/n;
  end
end
s=(m+1)/2;
for x=1:1:row
  for y=1:1:col
    b(x,y)=a(x,y);
  end
end
for x=s:1:row-s
  for y=s:1:col-s
    b(x,y)=0;
  end
end
for x=x:1:row-s
  for y=s:1:col-s
    for i=1:1:m
      for j=1:1:m
        b(x,y)=a(x-s+i,y-s+j)*w(i,j)+b(x,y);
      end
    end
  end
end

subplot(3,1,1)
imshow(uint8(a))
title('Original image');

subplot(3,1,2)
imshow(uint8(b))
title('Low Pass Filtering');

c=conv2(a,w);
subplot(3,1,3)
imshow(uint8(c))
title('Low Pass Filtered Image Using MATLAB');
