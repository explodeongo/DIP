clear all
clc
a=imread('dil.jpg')
p=size(a)
%%using the inbuilt MATLAB function for comparison %%
s=strel('square',3);
d1=imdilate(a,s);
d2=imerode(a,s);
%%writing our own program %%
w=[1 1 1;1 1 1;1 1 1];
for x=2:1:p(1)-1
  for y=2:1:p(2)-1
    a1=[w(1)*a(x-1,y-1) w(2)*a(x-1,y) w(3)*a(x-1,y+1) w(4)*a(x,y-1) w(5)*a(x,y) w(6)*a(x,y+1) w(7)*a(x-1,y-1) w(8)*a(x+1,y) w(9)*a(x+1,y+1)];
    A1(x,y)=max(a1);  %Dilation%
    A2(x,y) = min(a1);  %Erosion%
  endfor
endfor
figure(1),imshow(a) %Normalizing might be required
figure(2),imshow(d1)
figure(3),imshow(d2)
figure(4),imshow(A1)
figure(5),imshow(A2)

