clear all
clc
a = imread('test.png')
a = double(a);
[row col] = size(a);
h = zeros (1, 300);
for n = 1:1:row
  for m = 1:1:col
    if a(n,m)== 0
        a(n,m) =1;
    end
  end
end
for n = 1:1:row
    for m = 1:1: col
      t = a(n,m);
      h(t) = h(t) + 1;
    end
end

%%PLotting%%
figure(1)
imshow(uint8(a))
figure(2)
bar(h)

