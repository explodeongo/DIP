% MATLAB Program for Image Morphological Operations: Erosion and Dilation

% Read a binary image
binary_img = imread('Saturn.jpg'); % Replace 'binary_image.png' with your binary image file

% Display the original binary image
figure;
subplot(1, 3, 1); imshow(binary_img); title('Original Binary Image');

% Structuring element (SE) for morphological operations
se = strel('square', 3); % You can adjust the size and shape of the structuring element

% a. Erosion
eroded_img = imerode(binary_img, se);

% Display the eroded image
subplot(1, 3, 2); imshow(eroded_img); title('Eroded Image');

% b. Dilation
dilated_img = imdilate(binary_img, se);

% Display the dilated image
subplot(1, 3, 3); imshow(dilated_img); title('Dilated Image');

