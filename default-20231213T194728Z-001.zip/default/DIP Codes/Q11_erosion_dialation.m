% Read a binary image
binary_image = imread('binary_image1.png');

% Create a disk-shaped structuring element for erosion
radius = 5;  % You can adjust the size as needed
se_erosion = strel('arbitrary', ones(radius*2+1, radius*2+1));

% Perform erosion
eroded_image = imerode(binary_image, se_erosion);

% Create a disk-shaped structuring element for dilation
se_dilation = strel('arbitrary', ones(radius*2+1, radius*2+1));

% Perform dilation
dilated_image = imdilate(binary_image, se_dilation);

% Display the results
figure;
subplot(1, 3, 1), imshow(binary_image), title('Original Binary Image');
subplot(1, 3, 2), imshow(eroded_image), title('Eroded Image');
subplot(1, 3, 3), imshow(dilated_image), title('Dilated Image');

