clear all
clc
aa = imread("Saturn.jpg");
a = double(aa)
c =255;
b = c-a;
figure(1)
imshow(uint8(a));
figure(2)
imshow(uint8(b));
