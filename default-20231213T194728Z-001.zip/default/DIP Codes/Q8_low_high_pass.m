%Low pass Filter
% Read an image
original_image = imread('saturn2.jpeg');

% Define the standard deviation (sigma) for the Gaussian filter
sigma = 50;

% Create a Gaussian filter
gaussian_filter = fspecial('gaussian', [5 5], sigma);

% Apply the filter to the image
smoothed_image = imfilter(original_image, gaussian_filter, 'conv');

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(smoothed_image), title('Smoothed Image');

%High Pass Filter
% Read an image
original_image = imread('Saturn.jpg');

% Create a Laplacian filter
laplacian_filter = fspecial('laplacian');

% Apply the filter to the image
high_pass_image = imfilter(original_image, laplacian_filter, 'conv');

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(high_pass_image), title('High-Pass Filtered Image');

