%part a Translation
% Read an image
original_image = imread('binary_image3.png');

% Define translation parameters (tx and ty)
tx = 30;
ty = 20;

% Perform translation
translated_image = imtranslate(original_image, tx, ty);

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(translated_image), title('Translated Image');

%part b Scaling
% Read an image
original_image = imread('binary_image3.png');

% Define scaling factors (sx and sy)
sx = 1.5;
sy = 1.5;

% Perform scaling
scaled_image = imresize(original_image, [round(sx*size(original_image,1)), round(sy*size(original_image,2))]);

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(scaled_image), title('Scaled Image');

%part c Rotation
% Read an image
original_image = imread('binary_image3.png');

% Define rotation angle (in degrees)
theta = 30;

% Perform rotation
rotated_image = imrotate(original_image, theta, 'bilinear', 'crop');

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(rotated_image), title('Rotated Image');

%part d  Shrinking
% Read an image
original_image = imread('saturn2.jpeg');

% Define scaling factors less than 1 for shrinking
sx = 0.8;
sy = 0.8;

% Perform shrinking
shrunk_image = imresize(original_image, [round(sy*size(original_image, 1)), round(sx*size(original_image, 2))]);

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(shrunk_image), title('Shrunk Image');

%part e Zooming
% Read an image
original_image = imread('saturn2.jpeg');

% Define scaling factors greater than 1 for zooming
sx = 3.5;
sy = 5.5;

% Perform zooming
zoomed_image = imresize(original_image, [round(sy*size(original_image, 1)), round(sx*size(original_image, 2))]);

% Display the results
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(zoomed_image), title('Zoomed Image');




