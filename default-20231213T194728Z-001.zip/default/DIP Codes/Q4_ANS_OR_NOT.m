%to make a binary image
% Create a white image
%binary_image1 = ones(200, 200); % Modify the size as needed

% Define a black rectangle
%binary_image1(50:150, 50:150) = 0;% make 0 as 1 if you want black color outside and white inside

% Save the binary image
%imwrite(binary_image1, 'binary_image3.png');

%part a AND
% Read two binary images (0 and 1 values)
image1 = imread('binary_image1.png');
image2 = imread('binary_image2.png');

% Perform AND operation
result_image = bitand(image1, image2);

% Display the result
figure;
subplot(1, 3, 1), imshow(image1), title('Binary Image 1');
subplot(1, 3, 2), imshow(image2), title('Binary Image 2');
subplot(1, 3, 3), imshow(result_image), title('AND Operation Result');

%part b OR
% Read two binary images (black and white)
image1 = imread('binary_image1.png');
image2 = imread('binary_image2.png');

% Perform OR operation
result_image = bitor(image1, image2);

% Display the result
figure;
subplot(1, 3, 1), imshow(image1), title('Image 1');
subplot(1, 3, 2), imshow(image2), title('Image 2');
subplot(1, 3, 3), imshow(result_image), title('OR Operation Result');


%part c intersection
% Read two binary images (black and white)
image1 = imread('binary_image1.png');
image2 = imread('binary_image2.png');

% Perform intersection
result_image = bitand(image1, image2);

% Display the result
figure;
subplot(1, 3, 1), imshow(image1), title('Image 1');
subplot(1, 3, 2), imshow(image2), title('Image 2');
subplot(1, 3, 3), imshow(result_image), title('Intersection Result');

%part d NOT
% Read a grayscale image
original_image = imread('binary_image1.png');

% Load the image package (if not already loaded)
pkg load image;

% Perform NOT operation (Negative image)
negative_image = imcomplement(original_image);

% Display the result
figure;
subplot(1, 2, 1), imshow(original_image), title('Original Image');
subplot(1, 2, 2), imshow(negative_image), title('Negative Image');




