% MATLAB Program for Histogram Calculation and Equalization

% a. Histogram Calculation and Equalization using Standard MATLAB Function
clc;
clear all;

% Read an image
original_img = imread('saturn2.jpeg'); % Replace 'lena.jpg' with your image file

% Convert the image to grayscale if it is in RGB format
gray_img = rgb2gray(original_img);

% a.1. Histogram Calculation using MATLAB Function
hist_original = imhist(gray_img);

% a.2. Histogram Equalization using MATLAB Function
equalized_img = histeq(gray_img);

% a.3. Histogram Calculation of Equalized Image
hist_equalized = imhist(equalized_img);

% Display the results using MATLAB functions
figure;
subplot(2, 3, 1); imshow(gray_img); title('Original Image');
subplot(2, 3, 2); plot(hist_original); title('Histogram of Original Image');
subplot(2, 3, 3); imshow(equalized_img); title('Equalized Image');
subplot(2, 3, 4); plot(hist_equalized); title('Histogram of Equalized Image');

% b. Histogram Calculation and Equalization without using MATLAB Functions
% b.1. Custom Histogram Calculation
hist_custom = zeros(256, 1);
[M, N] = size(gray_img);

for i = 1:M
    for j = 1:N
        intensity = gray_img(i, j);
        hist_custom(intensity + 1) = hist_custom(intensity + 1) + 1;
    end
end

% b.2. Custom Histogram Equalization
cdf = cumsum(hist_custom) / (M * N);
equalized_custom_img = zeros(M, N);

for i = 1:M
    for j = 1:N
        intensity = gray_img(i, j);
        equalized_custom_img(i, j) = round(cdf(intensity + 1) * 255);
    end
end

% b.3. Custom Histogram Calculation of Equalized Image
hist_equalized_custom = zeros(256, 1);

for i = 1:M
    for j = 1:N
        intensity = equalized_custom_img(i, j);
        hist_equalized_custom(intensity + 1) = hist_equalized_custom(intensity + 1) + 1;
    end
end

% Display the results without using MATLAB functions
subplot(2, 3, 5); imshow(uint8(equalized_custom_img)); title('Custom Equalized Image');
subplot(2, 3, 6); plot(hist_equalized_custom); title('Histogram of Custom Equalized Image');

