% MATLAB Program for Digital Image Processing in Octave

% a. Become familiar with MATLAB Basic commands
clc;
clear all;

% Load the image package
pkg load image

% b. Read and display image in Octave
img = imread('saturn2.jpeg'); % Replace 'lena.jpg' with the actual image file
figure;
imshow(img);
title('Original Image');

% c. Resize given image
resized_img = imresize(img, 0.5); % Resize to 50%
figure;
imshow(resized_img);
title('Resized Image');

% d. Convert given color image into grayscale image
gray_img = rgb2gray(img);
figure;
imshow(gray_img);
title('Grayscale Image');

% e. Convert given color/gray-scale image into black & white image
threshold = 128;
bw_img = im2bw(gray_img, threshold/255);
figure;
imshow(bw_img);
title('Black & White Image');

% f. Draw image profile
profile_line = gray_img(100, :); % Example: Profile along row 100
figure;
plot(profile_line);
title('Image Profile');
xlabel('Pixel Position');
ylabel('Intensity');

% g. Separate color image into three R G & B planes
red_plane = img(:,:,1);
green_plane = img(:,:,2);
blue_plane = img(:,:,3);

% Display individual color planes
figure;
subplot(1, 3, 1); imshow(red_plane); title('Red Plane');
subplot(1, 3, 2); imshow(green_plane); title('Green Plane');
subplot(1, 3, 3); imshow(blue_plane); title('Blue Plane');

% h. Create color image using R, G and B three separate planes
reconstructed_img = cat(3, red_plane, green_plane, blue_plane);
figure;
imshow(reconstructed_img);
title('Reconstructed Color Image');

% i. Flow control and LOOP in Octave
for i = 1:5
    disp(['Iteration ' num2str(i)]);
end

% j. Write given 2-D data in image file
data_to_write = randn(100, 100); % Example: Random 2-D data
imwrite(data_to_write, 'output_image.png'); % Writes the data to an image file
disp('2-D Data written to output_image.png');

