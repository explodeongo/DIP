% Load the image package from Octave Forge
%pkg load image;
%part a Add two image
% Read two images
image1 = imread('binary_image1.png');
image2 = imread('binary_image2.png');

% Ensure both images have the same size
if size(image1) ~= size(image2)
    error('Both images must have the same dimensions.');
end

% Perform addition
result_image = imadd(image1, image2);

% Display the result
figure;
subplot(1, 3, 1), imshow(image1), title('Image 1');
subplot(1, 3, 2), imshow(image2), title('Image 2');
subplot(1, 3, 3), imshow(result_image), title('Addition Result');

%part b subtract one image from other
% Read two images
image1 = imread('binary_image1.png');
image2 = imread('binary_image3.png');

% Ensure both images have the same size
if size(image1) ~= size(image2)
    error('Both images must have the same dimensions.');
end

% Perform subtraction
result_image = imsubtract(image1, image2);

% Display the result
figure;
subplot(1, 3, 1), imshow(image1), title('Image 1');
subplot(1, 3, 2), imshow(image2), title('Image 2');
subplot(1, 3, 3), imshow(result_image), title('Subtraction Result');

% Read an image
image = imread('binary_image1.png');

% Convert the image to grayscale if it's a color image
if size(image, 3) == 3
    image = rgb2gray(image);
end

% Calculate the mean value
mean_value = mean(image(:));

% Display the result
figure;
subplot(1, 2, 1), imshow(image), title('Original Image');
subplot(1, 2, 2), text(0.5, 0.5, ['Mean Value: ', num2str(mean_value)], ...
    'FontSize', 14, 'HorizontalAlignment', 'center');

