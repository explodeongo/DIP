% MATLAB Program for Image Frequency Domain Filtering

% Read an image
original_img = imread('saturn2.jpeg'); % Replace 'lena.jpg' with your image file

% Convert the image to grayscale if it is in RGB format
gray_img = rgb2gray(original_img);

% Display the original image
figure;
subplot(2, 3, 1); imshow(gray_img); title('Original Image');

% a. Apply FFT on the given image
fft_img = fft2(gray_img);

% Display the magnitude spectrum of the FFT
magnitude_spectrum = log(1 + abs(fftshift(fft_img)));
subplot(2, 3, 2); imshow(magnitude_spectrum, []); title('Magnitude Spectrum (FFT)');

% b. Perform Low Pass Filtering in Frequency Domain
% Define the filter (e.g., Gaussian filter)
[M, N] = size(gray_img);
[X, Y] = meshgrid(1:N, 1:M);
sigma = 20; % Adjust the standard deviation of the Gaussian filter
low_pass_filter = exp(-((X - N/2).^2 + (Y - M/2).^2) / (2 * sigma^2));

% Apply the filter in the frequency domain
filtered_fft_img_low_pass = fft_img .* low_pass_filter;

% Display the magnitude spectrum of the filtered image
magnitude_spectrum_low_pass = log(1 + abs(fftshift(filtered_fft_img_low_pass)));
subplot(2, 3, 3); imshow(magnitude_spectrum_low_pass, []); title('Magnitude Spectrum (Low Pass)');

% c. Perform High Pass Filtering in Frequency Domain
% Use the complement of the low-pass filter as the high-pass filter
high_pass_filter = 1 - low_pass_filter;

% Apply the filter in the frequency domain
filtered_fft_img_high_pass = fft_img .* high_pass_filter;

% Display the magnitude spectrum of the filtered image
magnitude_spectrum_high_pass = log(1 + abs(fftshift(filtered_fft_img_high_pass)));
subplot(2, 3, 4); imshow(magnitude_spectrum_high_pass, []); title('Magnitude Spectrum (High Pass)');

% d. Apply IFFT to reconstruct images
reconstructed_img_low_pass = ifft2(ifftshift(filtered_fft_img_low_pass));
reconstructed_img_high_pass = ifft2(ifftshift(filtered_fft_img_high_pass));

% Display the reconstructed images
subplot(2, 3, 5); imshow(uint8(abs(reconstructed_img_low_pass))); title('Reconstructed Image (Low Pass)');
subplot(2, 3, 6); imshow(uint8(abs(reconstructed_img_high_pass))); title('Reconstructed Image (High Pass)');

