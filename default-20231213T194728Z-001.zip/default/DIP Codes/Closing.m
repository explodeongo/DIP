clear all
clc
a = imread('image.bmp');

a = double(a);
p = size(a);
w = [1 1 1; 1 1 1; 1 1 1];
for x=2:1:p(1)-1
  for y=2:1:p(2)-1
    a1 =[w(1)*a(x-1,y-1) w(2)*a(x-1,y) w(3)*a(x-1,y+1) w(4)*a(x,y-1) w(5)*a(x,y) w(6)*a(x,y+1) w(7)*a(x+1,y-1) w(8)*a(x+1,y) w(9)*a(x+1,y+1)];
    A1(x,y) = max(a1);
  endfor
end

q = size(A1)
 for x=2:1:q(1)-1
  for y=2:1:q(2)-1
    a11 =[w(1)*A1(x-1,y-1) w(2)*A1(x-1,y) w(3)*A1(x-1,y+1) w(4)*A1(x,y+1) w(5)*A1(x,y) w(6)*A1(x,y+1) w(7)*A1(x+1,y-1) w(8)*A1(x+1,y) w(9)*A1(x+1,y+1)];
    A2(x,y) = min(a11);
  endfor
end

 figure(1), imshow(uint8(a))
 figure(3), imshow(uint8(A1))
 figure(2), imshow(uint8(A2))
