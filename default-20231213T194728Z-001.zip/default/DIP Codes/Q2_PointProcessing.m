% MATLAB Program for Point Processing Methods

% a. Obtain Negative image
clc;
clear all;

% Read the original image
original_img = imread('saturn2.jpeg'); % Replace 'lena.jpg' with your image file

% Obtain negative image
negative_img = 255 - original_img;

% Display original and negative images
figure;
subplot(1, 2, 1); imshow(original_img); title('Original Image');
subplot(1, 2, 2); imshow(negative_img); title('Negative Image');

% b. Obtain Flip image
% Flip the original image horizontally
flip_img = flip(original_img, 2);

% Display original and flipped images
figure;
subplot(1, 2, 1); imshow(original_img); title('Original Image');
subplot(1, 2, 2); imshow(flip_img); title('Flipped Image');

% c. Thresholding
% Convert the original image to grayscale
gray_img = rgb2gray(original_img);

% Perform thresholding (example: threshold at 128)
threshold = 128;
thresholded_img = gray_img > threshold;

% Display original and thresholded images
figure;
subplot(1, 2, 1); imshow(gray_img); title('Grayscale Image');
subplot(1, 2, 2); imshow(thresholded_img); title('Thresholded Image');

% d. Contrast stretching
% Stretch the contrast of the grayscale image
contrast_stretched_img = imadjust(gray_img);

% Display original and contrast-stretched images
figure;
subplot(1, 2, 1); imshow(gray_img); title('Grayscale Image');
subplot(1, 2, 2); imshow(contrast_stretched_img); title('Contrast-Stretched Image');

