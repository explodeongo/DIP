clear all
clc
a = imread('Saturn.jpg');
a =double(a);
[row col] = size(a);
a =a+1;
w = min(min(a));
constant = 255/(max(max(a))-min(min(a)));
cmin = 0;
for x1 =1:1:row
  for y1 =1:1:col
    c(x1,y1) = constant*(a(x1,y1)-w)+cmin;

  endfor
end

h = zeros(1,300);
for n=1:1:row
  for m=1:1:col
    t=a(n,m);
    h(t) = h(t)+1;
    h(12)
  endfor
end

figure(1), bar(h)
c = c+1;
h = zeros(1,400);

for n= 1:1:row
  for m=1:1:col
    t=round(c(n,m));
    h(t)=h(t)+1;
  end
end
figure(2), bar(h)
figure(3),imshow(uint8(a))
figure(4),imshow(uint8(c))
