clear all
clc
a = imread('Saturn.jpg');
a = double(a);
[row,col] =size(a)
m = input("Enter the mask size");
n = m^2;
for i=1:1:m
  for j=1:1:m
    w(i,j)=1/n;
  endfor
end

s = (m+1)/2;
for x = 1:1:row
  for y=1:1:col
    b(x,y) = a(x,y);
  endfor
end

for x= s:1:row-s
  for y= s:1:col-s
    b(x,y) =0;
  endfor
end

for x= s:1:row-s
  for y= s:1:col-s
    for i= 1:1:m
      for j= 1:1:m-1
        b(x,y)= a(x-s+i,y-s+j)*w(i,j)+b(x,y);
      endfor
    endfor
  endfor
end

subplot(3,1,1)
imshow(uint8(a))
title("Original Image");
subplot(3,1,2)
imshow(uint8(b))
title("Low pass filtered Image");
c = conv2(a,w);
subplot(3,1,3)
imshow(uint8(c))
title("Low pass filtered Image: using MATLAB");
