%part a. Image Restoration
% Image Restoration (Example: Wiener Filter)

% Read the original image
original_image = imread('girl.jpeg');

% Simulate some noise (for example, Gaussian noise)
noisy_image = imnoise(original_image, 'gaussian', 0, 0.01);

% Estimate noise power
noise_var = var(double(original_image(:) - noisy_image(:)));

% Apply Wiener filter for restoration
restored_image = wiener2(noisy_image, [5, 5], noise_var);

% Display results
figure;
subplot(1, 3, 1), imshow(original_image), title('Original Image');
subplot(1, 3, 2), imshow(noisy_image), title('Noisy Image');
subplot(1, 3, 3), imshow(restored_image), title('Restored Image');

%b. Remove Salt and Pepper Noise
% Remove Salt and Pepper Noise (Example: Median Filter)

% Read the image with salt and pepper noise
noisy_image = imread('girl.jpeg');

% Apply a median filter for denoising
denoised_image = medfilt2(noisy_image, [3, 3]);

% Display results
figure;
subplot(1, 2, 1), imshow(noisy_image), title('Noisy Image');
subplot(1, 2, 2), imshow(denoised_image), title('Denoised Image');

%part c. Minimize Gaussian Noise
% Read the image with Gaussian noise
noisy_image = imread('girl.jpeg');

% Convert the image to double for processing
noisy_image = im2double(noisy_image);

% Define a Gaussian filter kernel
sigma = 2;
filter_size = 6 * sigma + 1;
gaussian_filter = fspecial('gaussian', filter_size, sigma);

% Apply Gaussian smoothing for noise reduction
smoothed_image = imfilter(noisy_image, gaussian_filter, 'conv', 'replicate');

% Display results
figure;
subplot(1, 2, 1), imshow(noisy_image), title('Noisy Image');
subplot(1, 2, 2), imshow(smoothed_image), title('Smoothed Image');


%part d. Median Filter
% Median Filter (Example: Removing Impulse Noise)

% Read the image with impulse (salt and pepper) noise
noisy_image = imread('girl.jpeg');

% Apply a median filter for denoising
denoised_image = medfilt2(noisy_image, [3, 3]);

% Display results
figure;
subplot(1, 2, 1), imshow(noisy_image), title('Noisy Image');
subplot(1, 2, 2), imshow(denoised_image), title('Denoised Image');

